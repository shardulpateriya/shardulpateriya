# CNN Waste Segregation

This project implements a Convolutional Neural Network (CNN) to classify waste images into 7 categories:
- Food Waste
- Metal
- Paper
- Plastic
- Other
- Cardboard
- Glass

## 🚀 Features
- Image preprocessing and augmentation
- CNN model training
- Model evaluation with classification report and confusion matrix
- Data visualization

## 📂 Dataset
The dataset is available on Kaggle: [Waste Classification Dataset](https://www.kaggle.com)

## 🛠 How to Run
```bash
pip install -r requirements.txt
jupyter notebook waste_classification.ipynb
```

## 📈 Results
- Accuracy: ~85% (can be improved using transfer learning)
